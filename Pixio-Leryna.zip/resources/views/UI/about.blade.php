@extends('layouts.home')

@section('content')

<div id="fh5co-our-services" data-section="services">
  <div class="container-fluid">
    <div class="row about-wrap">
      <div class="col-md-6 first-col col-xs-12">
        <img src="images/public/bg1.png"/>
      </div>
      <div class="col-md-6 second-col col-xs-12">
        <div class="about-leryna-wrap">
          <p class="header">Về Leryna</p>
          <p class="description">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend te</p>
        </div>
      </div>
    </div>
  </div>
</div>

@endsection
