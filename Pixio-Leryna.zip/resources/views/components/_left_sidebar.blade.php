<div class="col-lg-2 col-md-2 left-sidebar">
  <div class="left-content">
    <a href="admin">
      <div class="header-content">
        <i class="fa fa-user-circle"></i>
         <span>Admin Page</span>
      </div>
    </a>
    <div class="select-admin-wrap">
      <div class="item-admin">
        <div class="item-big-element">
          <div class="select-item-wrap">
            <i class="fa fa-edit"></i>
            <span> Blog</span>
          </div>
          <ul class="child-el-wrap">
            <a href="/admin-blog"><li>List Blogs</li></a>
            <a href="/upload-blog"><li>Upload Blogs</li></a>
          </ul>
        </div>
      </div>
      <div class="item-admin">
        <div class="item-big-element">
          <div class="select-item-wrap">
            <i class="fa fa fa-gears"></i>
            <span> Products</span>
          </div>
          <ul class="child-el-wrap">
            <a href="/admin-product"><li>List Products</li></a>
            <a href="/upload-product"><li>Upload Products</li></a>
          </ul>
        </div>
      </div>
    </div>

  </div>
</div>
