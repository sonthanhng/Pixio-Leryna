<?php $__env->startSection('header'); ?>
  <!-- include summernote css/js -->
  <link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">
  <script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.js"></script>
  <script src="<?php echo e(asset('/js/blog.js')); ?>"></script>
  <script>
    $(document).ready(function() {
      $('#blog-content').summernote('code', <?php echo json_encode($blog->content); ?>);
      $('.blog-language').val(<?php echo json_encode($blog->language); ?>)
    })
  </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row content-section">
    <?php echo $__env->make('components._left_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="col-lg-10 col-md-10" style="background-color: #F7F7F7">
      <div class="right-content blog-section">
        <?php if(session('success')): ?>
          <div class="alert alert-success animated fadeOutUp">
            <?php echo e(session('success')); ?>

          </div>
        <?php endif; ?>

        <div class="upload-blog-section">
          <p class="header">Edit Blog</p>
          <?php echo Form::open(['url' => 'admin-blog/edit', 'enctype' => 'multipart/form-data']); ?>

          <?php echo e(Form::text('blog-id', $blog->id, ['class' => 'form-control blog-id', 'id' => 'blog-id'])); ?>

          <div class="form-group">
            <?php echo e(Form::label('blog-name', 'Blog Name')); ?>

            <?php echo e(Form::text('blog-name', $blog->title, ['class' => 'form-control blog-name'])); ?>

          </div>
          <div class="form-group">
            <?php echo e(Form::textarea('blog-description', $blog->description, ['class' => 'form-control blog-description', 'id' => 'blog-description'])); ?>

          </div>
          <div class="form-group">
            <?php echo e(Form::label('blog-content', 'Blog Content')); ?>

            <textarea id="blog-content" name="blog-content"></textarea>
          </div>
          <div class="form-group">
            <?php echo e(Form::file('image', ['placeholder' => 'Select thumbnail image'])); ?>

          </div>
          <div>
            <?php echo e(Form::submit('Upload', ['class' => 'btn btn-primary'])); ?>

          </div>
          <?php echo Form::close(); ?>

        </div>

      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>