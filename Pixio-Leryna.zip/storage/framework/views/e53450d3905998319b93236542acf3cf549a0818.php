<?php $__env->startSection('header'); ?>
  <!-- include summernote css/js -->
  <link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">
  <script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.js"></script>
  <script src="<?php echo e(asset('/js/product.js')); ?>"></script>
  <script>
    $(document).ready(function() {
      $('#product-content').summernote('code', <?php echo json_encode($product->content); ?>);
      $('.product-language').val(<?php echo json_encode($product->language); ?>)
    })
  </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row content-section">
    <?php echo $__env->make('components._left_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="col-lg-10 col-md-10" style="background-color: #F7F7F7">
      <div class="right-content product-section">
        <?php if(session('success')): ?>
          <div class="alert alert-success animated fadeOutUp">
            <?php echo e(session('success')); ?>

          </div>
        <?php endif; ?>

        <div class="upload-product-section">
          <p class="header">Edit Product</p>
          <?php echo Form::open(['url' => 'admin-product/edit', 'enctype' => 'multipart/form-data']); ?>

          <?php echo e(Form::text('product-id', $product->id, ['class' => 'form-control product-id', 'id' => 'product-id'])); ?>

          <div class="form-group">
            <?php echo e(Form::label('product-name', 'Product Name')); ?>

            <?php echo e(Form::text('product-name', $product->title, ['class' => 'form-control product-name'])); ?>

          </div>
          <div class="form-group">
            <?php echo e(Form::label('product-content', 'Product Content')); ?>

            <textarea id="product-content" name="product-content"></textarea>
          </div>
          <div class="form-group">
            <?php echo e(Form::file('image', ['placeholder' => 'Select thumbnail image'])); ?>

          </div>
          <div>
            <?php echo e(Form::submit('Upload', ['class' => 'btn btn-primary'])); ?>

          </div>
          <?php echo Form::close(); ?>

        </div>

      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>