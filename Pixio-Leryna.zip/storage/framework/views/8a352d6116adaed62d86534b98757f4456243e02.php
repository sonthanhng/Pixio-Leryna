<?php $__env->startSection('header'); ?>
  <!-- include summernote css/js -->
  <link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">
  <script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.js"></script>
  <script src="<?php echo e(asset('/js/product.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row content-section">
    <?php echo $__env->make('components._left_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="col-lg-10 col-md-10" style="background-color: #F7F7F7">
      <div class="right-content product-section">
        <?php if(session('success')): ?>
          <div class="alert alert-success animated fadeOutUp">
            <?php echo e(session('success')); ?>

          </div>
        <?php endif; ?>

        <div class="upload-product-section">
          <p class="header">Upload Product</p>
          <?php echo Form::open(['url' => 'admin-product/upload', 'enctype' => 'multipart/form-data']); ?>

          <div class="form-group">
            <?php echo e(Form::text('product-name', '', ['class' => 'form-control product-name'])); ?>

          </div>
          <div class="form-group">
            <textarea id="product-content" name="product-content"></textarea>
          </div>
          <div class="form-group">
            <?php echo Form::file('gallery[]', array('multiple'=>true,'accept'=>'image/*')); ?>

            <!-- <?php echo e(Form::file('image', ['placeholder' => 'Select thumbnail image'])); ?> -->
          </div>
          <div>
            <?php echo e(Form::submit('Upload', ['class' => 'btn btn-primary'])); ?>

          </div>
          <?php echo Form::close(); ?>

        </div>

      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>