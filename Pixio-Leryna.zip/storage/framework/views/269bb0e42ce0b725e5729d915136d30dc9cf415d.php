<?php $__env->startSection('content'); ?>
  <div class="blog-page">
    <div id="fh5co-testimonials" data-section="testimonials">
  		<div class="container">
  			<p class="header-section">Blog</p>
				<div class="row">
          <?php $count_blog = 0; ?>
    			<?php if(count($blogs) > 0): ?>
    				<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    					<?php
    						$count_blog++;
    						$colClass = "";
    						if ($count_blog % 3 === 1) {
    							$colClass = "first-col";
                  echo '<div class="row">';
    						} else if ($count_blog % 3 === 0) {
    							$colClass = "last-col";
                  echo '</div>';
    						}
    					?>
    					<div class="col-md-4 col <?php echo $colClass ?>">
    						<div class="post-wrap">
    							<img src="<?php echo e($blog->thumbnailUrl); ?>"/>
    							<div class="content-wrap">
    								<p class="title"><?php echo e($blog->title); ?></p>
    								<p class="content"><?php echo e($blog->description); ?></p>
    							</div>
                  <a class="btn-read-more" href="/blogs/<?php echo e($blog->id); ?>">Đọc tiếp..</a>
    						</div>
    					</div>
    				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    			<?php endif; ?>
  		</div>
  	</div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>