<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row content-section">
    <?php echo $__env->make('components._left_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="col-lg-10 col-md-10" style="background-color: #F7F7F7">
      <div class="right-content blog-section">
        <?php if(session('success')): ?>
          <div class="alert alert-success animated fadeOutUp">
            <?php echo e(session('success')); ?>

          </div>
        <?php endif; ?>

        <div class="show-blog">
          <p class="header">List of orders</p>
          <table class="table">
            <thead>
              <tr>
                <th>Tên</th>
                <th>Email</th>
                <th>Số điện thoại</th>
                <th>Số lượng</th>
              </tr>
            </thead>
            <tbody>
              <?php if(count($orders) > 0): ?>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td style="width: 25%;"><?php echo e($order->name); ?></td>
                    <td style="width: 25%;"><?php echo e($order->email); ?></td>
                    <td style="width: 25%;"><?php echo e($order->phonenumber); ?></td>
                    <td style="width: 25%;"><?php echo e($order->number); ?></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>

      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>