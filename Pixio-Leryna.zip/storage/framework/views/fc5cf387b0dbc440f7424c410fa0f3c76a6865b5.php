<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row content-section">
    <?php echo $__env->make('components._left_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="col-lg-10 col-md-10" style="background-color: #F7F7F7">
      <div class="right-content">
        <p>
          You are logged in!
        </p>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>