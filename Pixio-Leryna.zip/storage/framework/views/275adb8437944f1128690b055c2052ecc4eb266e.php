<?php $__env->startSection('content'); ?>
  <div class="product-page">
	   <div id="fh5co-about-us" data-section="about">
		<div class="container">
      <p class="header-section">Sản phẩm</p>
			<div class="row" id="about-us">
        <div class="product-section row">
					<?php if(count($products) > 0): ?>
						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-4 col-xs-12 product-wrap to-animate fadeInUp animated">
							<a href="/products/<?php echo e($product->id); ?>">
								<div style="background: url(<?php echo e($product->thumbnailUrl); ?>); background-size: cover; height: 300px; width: 100%;">
									<div class="product-hover">
									</div>
								</div>
								<div class="product-description">
									<span class="title"><?php echo e($product->title); ?></span>
									<a class="btn-buy-now" href="/products/<?php echo e($product->id); ?>">Mua ngay</a>
								</div>
							</a>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>