
<!DOCTYPE html>
	<html class="no-js">
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Leryna</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Template by FREEHTML5.CO" />
	<meta name="keywords" content="free html5, free template, free bootstrap, html5, css3, mobile first, responsive" />
	<meta name="author" content="FREEHTML5.CO" />

  <!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
	<link rel="shortcut icon" href="favicon.ico">

	<link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,300,600,400italic,700' rel='stylesheet' type='text/css'>

	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Simple Line Icons -->
	<link rel="stylesheet" href="css/simple-line-icons.css">
	<!-- Owl Carousel -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/custom.css">
	<link rel="stylesheet" href="css/responsive.css">


	<script src="js/modernizr-2.6.2.min.js"></script>

	</head>
	<body>
		<header role="banner" id="fh5co-header">
				<div class="container">
				    <nav class="navbar navbar-default">
			        <div class="navbar-header">
						<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"><i></i></a>
			          	<a class="navbar-brand" href="index.html">
										<img src="images/public/logo.png"/>
									</a>
			        </div>
			        <div id="navbar" class="navbar-collapse collapse">
			          <ul class="nav navbar-nav navbar-right">
			            <li class="active"><a href="index.html"><span>Trang chủ</span></a></li>
			            <li><a href="product.html"><span>Sản phẩm</span></a></li>
			            <li><a href="about.html"><span>Về Leryna</span></a></li>
			            <li><a href="blog.html"><span>Blog</span></a></li>
			            <li><a href="contact.html"><span>Liên hệ</span></a></li>
			          </ul>
			        </div>
				    </nav>
			  </div>
		</header>

	<div id="slider" data-section="home">
		<div class="owl-carousel owl-carousel-fullwidth">
			<!-- You may change the background color here. -->
		    <div class="item" style="background: url('images/public/slider1.png'); height: 500px;">
		    	<div class="container" style="position: relative;">
		    	</div>
		    </div>
			<!-- You may change the background color here.  -->
		    <div class="item" style="background: url('images/public/slider1.png'); height: 500px;">
		    	<div class="container" style="position: relative;">
		    	</div>
		    </div>
		</div>
	</div>

	<div id="fh5co-about-us" data-section="about">
		<div class="container">
			<div class="row" id="about-us">
				<div class="col-md-8 col-xs-12 header-wrap">
					<h2 class="to-animate header">Công ty xuất khẩu dép xốp hàng đầu Việt Nam</h2>
				</div>
				<div class="product-section">
					<div class="col-md-4 product-wrap to-animate fadeInUp animated">
						<img src="images/public/products/product1.png"/>
						<div class="product-description">
							<span class="title">Dép giấy</span>
							<a class="btn-buy-now">Mua ngay</a>
						</div>
					</div>
					<div class="col-md-4 product-wrap to-animate fadeInUp animated">
						<img src="images/public/products/product1.png"/>
						<div class="product-description">
							<span class="title">Dép giấy</span>
							<a class="btn-buy-now">Mua ngay</a>
						</div>
					</div>
					<div class="col-md-4 product-wrap to-animate fadeInUp animated">
						<img src="images/public/products/product1.png"/>
						<div class="product-description">
							<span class="title">Dép giấy</span>
							<a class="btn-buy-now">Mua ngay</a>
						</div>
					</div>
					<div class="col-md-4 product-wrap to-animate fadeInUp animated">
						<img src="images/public/products/product1.png"/>
						<div class="product-description">
							<span class="title">Dép giấy</span>
							<a class="btn-buy-now">Mua ngay</a>
						</div>
					</div>
					<div class="col-md-4 product-wrap to-animate fadeInUp animated">
						<img src="images/public/products/product1.png"/>
						<div class="product-description">
							<span class="title">Dép giấy</span>
							<a class="btn-buy-now">Mua ngay</a>
						</div>
					</div>
					<div class="col-md-4 product-wrap to-animate fadeInUp animated">
						<img src="images/public/products/product1.png"/>
						<div class="product-description">
							<span class="title">Dép giấy</span>
							<a class="btn-buy-now">Mua ngay</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div id="fh5co-our-services" data-section="services">
		<div class="container-fluid">
			<div class="row about-wrap">
				<div class="col-md-6 first-col col-xs-12">
					<img src="images/public/bg1.png"/>
				</div>
				<div class="col-md-6 second-col col-xs-12">
					<div class="about-leryna-wrap">
						<p class="header">Về Leryna</p>
						<p class="description">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend te</p>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div id="fh5co-features" data-section="features">
		<div class="container-fluid">
			<div class="row">
			<div class="col-md-4 col-xs-12 col first-col">
				<p class="number">01</p>
				<p class="title">Chất lượng hàng đầu</p>
				<p class="description">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.</p>
			</div>
			<div class="col-md-4 col-xs-12 col">
				<p class="number">02</p>
				<p class="title">Uy tín số một</p>
				<p class="description">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.</p>
			</div>
			<div class="col-md-4 col-xs-12 col">
				<p class="number">03</p>
				<p class="title">Giá cả hợp lý</p>
				<p class="description">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.</p>
			</div>
		</div>
		</div>
	</div>

	<div id="fh5co-testimonials" data-section="testimonials">
		<div class="container">
			<p class="header-section">Bài viết nên đọc</p>
			<div class="col-md-4 col first-col">
				<div class="post-wrap">
					<img src="images/public/dep1.png"/>
					<div class="content-wrap">
						<p class="title">5 loại dép xốp thường gặp</p>
						<p class="content">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam feli</p>
					</div>
					<a class="btn-read-more">Đọc tiếp..</a>
				</div>
			</div>
			<div class="col-md-4 col">
				<div class="post-wrap">
					<img src="images/public/dep1.png"/>
					<div class="content-wrap">
						<p class="title">5 loại dép xốp thường gặp</p>
						<p class="content">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam feli</p>
					</div>
					<a class="btn-read-more">Đọc tiếp..</a>
				</div>
			</div>
			<div class="col-md-4 col last-col">
				<div class="post-wrap">
					<img src="images/public/dep1.png"/>
					<div class="content-wrap">
						<p class="title">5 loại dép xốp thường gặp</p>
						<p class="content">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam feli</p>
					</div>
					<a class="btn-read-more">Đọc tiếp..</a>
				</div>
			</div>
		</div>
	</div>
	<footer id="footer" role="contentinfo">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<p class="text-center">hello@leryna.com<br />+84 123 456 789<br>55 Phạm Văn Hai, P.2, Q.Tân Bình, TP.HCM</p>
				</div>
			</div>
		</div>
	</footer>


	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Owl Carousel -->
	<script src="js/owl.carousel.min.js"></script>

	<!-- Main JS (Do not remove) -->
	<script src="js/main.js"></script>

	</body>
</html>
